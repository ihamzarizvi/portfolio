﻿Thank you for your recent purchase of "Hendrie - Personal/CV/Resume HTML Template".

--------------------------------------


Overview:

Hendrie - Personal/CV/Resume HTML Template. Fully responsive and easy for you to edit. Hendrie with modern & clean design. 
Template focused on web-designers, digital professionals, programmers or photographers. It is perfect to promote your work!


--------------------------------------


Features:
- 3 Background Styles
(Image, Particles, Youtube)
- HTML5, CSS3, jQuery
- Fully Responsive
- Blog Post
- Valid HTML5 Code
- Cross browser
- Minimal and Clean
- LESS CSS Included
- Fonts Icons
- Google Fonts
- Ajax contact php
- Magnific Popup Portfolio
- jQuery Validation Plugin
- CSS3 Animations
- Documentation included


--------------------------------------


Icons used:

- Ionicons – http://ionicons.com/


--------------------------------------


Free Google Fonts used:

- Google Fonts, Hind
- Google Fonts, Montserrat
- Google Fonts, Eczar


--------------------------------------


Sourse & Credits:

Animate.css - https://daneden.github.io/animate.css/
jQuery - https://jquery.com/
Masonry - http://masonry.desandro.com/
imagesLoaded - http://imagesloaded.desandro.com/
Typed.js - https://github.com/mattboldt/typed.js/
jQuery Validation Plugin - http://jqueryvalidation.org/
Magnific Popup - http://dimsemenov.com/plugins/magnific-popup/
jquery.mb.YTPlayer - https://github.com/pupunzi/jquery.mb.YTPlayer
Multiple Filter Masonry - "http://dynamick.github.io/multiple-filter-masonry/
Particles.js - https://github.com/VincentGarreau/particles.js/
Scrollreveal - https://github.com/jlmakes/scrollreveal


--------------------------------------


Photos Credits:

- https://unsplash.com/
- https://www.pexels.com/
- http://graphicburger.com/


IMPORTANT: Images and Videos used in the Preview demo are not included in the downloaded package.


ThemeForest: https://themeforest.net/user/beshleyua
Email: beshleygame@mail.ru


Good luck.